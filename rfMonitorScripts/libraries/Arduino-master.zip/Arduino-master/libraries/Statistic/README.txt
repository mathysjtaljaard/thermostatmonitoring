
2012-05-19
-------------
This is a simple statistic library for the Arduino, version: 0.3.1
previous versions are not available.

2013-08-17 
------------
version: 0.3.2
http://arduino.cc/playground/Main/Statistics

