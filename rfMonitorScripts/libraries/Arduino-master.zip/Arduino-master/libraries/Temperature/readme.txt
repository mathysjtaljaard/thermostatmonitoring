
Small collection of temperature related functions

TODO: 
- make all celsius variants of them
- Class with option F / K / C ?

